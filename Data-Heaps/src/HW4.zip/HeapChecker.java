

public class HeapChecker {
	boolean addEltTester(IHeap hOrig, int elt, IBinTree hAdded) {

		if(hAdded.heapHuh()) {
			if(hOrig.hasOrigAdd(hOrig, elt, hAdded)) {
				return true;
			}
			return false;
			
		}
		return false;
    }
	
	
	  boolean remMinEltTester(IHeap hOrig, IBinTree hRemoved) {
		  if(hRemoved.heapHuh()) {
				if(hOrig.hasOrigRem(hOrig, hRemoved)) {
					return true;
				}
				return false;
			}
			return false;
	    }
}


